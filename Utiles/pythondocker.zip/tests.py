import random
from conexionMongo import *
from consultasFulcrum import *
from funciones import *


#infoTx(str(0),"ea510170d41e31872f919d9af0123d843481c0d5f2560609d565d515419acc59")
print(infoTx(str(0),"d63667e49701df10b51dfe347e6ed6f59a73f4ef3c883ad9cfee3d23064372a6"))