def returnApiToken ():
    return '7677426706:AAFSVslBTlCFOgdhNKSa5tkUVC_DG2fHbfQ'

def btcMainnetPass ():
    return "v0LHl9V4wsOjxPhS4i8jtCeSvVHuch_XW-5XAp-z-ck"

def btcTestnetPass ():
    return "c_prEI3Lr0Aj5nPF5Sq219J4j-HVzUcqpKkicBnj0VI"

def ipLocal ():
    return "192.168.1.184"